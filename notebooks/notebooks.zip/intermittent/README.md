# Intermittent Demand Forcast

## Croston's and Adjusted Croston Methods

## kalman filter and smoother

## Slow-moving items modeling approaches

## Multistage Generalized Linear Model (Multistage GLM)

## Examples

## Reference
